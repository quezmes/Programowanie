﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using lab_nr06_zd2.Models;

using lab_nr07_zd2.Models;

namespace lab_nr06_zd2
{
    public partial class Form1 : Form
    {
        private readonly ProductService _productService = new ProductService();
        
        private Product currentProduct;
        public Form1()
        {
           
            InitializeComponent();
            

        }
        private void QuantityBarLblUpdate()
        {

            lblQuatity.Text = String.Join(" ", "Quantity:", Quantitybar.Value);
        }
        private void Quantitybar_Scroll(object sender, EventArgs e)
        {
            QuantityBarLblUpdate();

        }
        private void button1_Click(object sender, EventArgs e)
        {
            var tag = (sender as Control).Tag;
            currentProduct = _productService.Products[int.Parse(tag.ToString())];

          productUserControl1.Update(currentProduct);
            Quantitybar.Maximum = (int)currentProduct.CurrentStock;
            Quantitybar.Value = 0;
            QuantityBarLblUpdate();

           
        }

        private void Quantitybar_Scroll_1(object sender, EventArgs e)
        {
            QuantityBarLblUpdate();
        }

        private void AddToCartBut_Click(object sender, EventArgs e)
        {
            cartUserControl11.UpdateCart( currentProduct, Quantitybar.Value);
            cartUserControl11.ShowTotalCost();
           
        }


    
    }
}
