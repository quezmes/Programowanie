﻿namespace lab_nr06_zd2
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.Quantitybar = new System.Windows.Forms.TrackBar();
            this.AddToCartBut = new System.Windows.Forms.Button();
            this.lblQuatity = new System.Windows.Forms.Label();
            this.cartUserControl11 = new lab_nr07_zd2.CartUserControl();
            this.productUserControl1 = new lab_nr06_zd2.ProductUserControl();
            ((System.ComponentModel.ISupportInitialize)(this.Quantitybar)).BeginInit();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(12, 12);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 0;
            this.button1.Tag = "0";
            this.button1.Text = "Produkt 1";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.AutoSizeChanged += new System.EventHandler(this.button1_Click);
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(12, 41);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 23);
            this.button2.TabIndex = 1;
            this.button2.Tag = "1";
            this.button2.Text = "Produkt 2";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.AutoSizeChanged += new System.EventHandler(this.button1_Click);
            this.button2.Click += new System.EventHandler(this.button1_Click);
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(12, 70);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(75, 23);
            this.button3.TabIndex = 2;
            this.button3.Tag = "2";
            this.button3.Text = "Produkt 3";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.AutoSizeChanged += new System.EventHandler(this.button1_Click);
            this.button3.Click += new System.EventHandler(this.button1_Click);
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(12, 99);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(75, 23);
            this.button4.TabIndex = 3;
            this.button4.Tag = "3";
            this.button4.Text = "Produkt 4";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.AutoSizeChanged += new System.EventHandler(this.button1_Click);
            this.button4.Click += new System.EventHandler(this.button1_Click);
            // 
            // button5
            // 
            this.button5.Location = new System.Drawing.Point(12, 128);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(75, 23);
            this.button5.TabIndex = 4;
            this.button5.Tag = "4";
            this.button5.Text = "Produkt 5";
            this.button5.UseVisualStyleBackColor = true;
            this.button5.AutoSizeChanged += new System.EventHandler(this.button1_Click);
            this.button5.Click += new System.EventHandler(this.button1_Click);
            // 
            // button6
            // 
            this.button6.Location = new System.Drawing.Point(12, 157);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(75, 23);
            this.button6.TabIndex = 5;
            this.button6.Tag = "5";
            this.button6.Text = "Produkt 6";
            this.button6.UseVisualStyleBackColor = true;
            this.button6.AutoSizeChanged += new System.EventHandler(this.button1_Click);
            this.button6.Click += new System.EventHandler(this.button1_Click);
            // 
            // Quantitybar
            // 
            this.Quantitybar.Location = new System.Drawing.Point(113, 341);
            this.Quantitybar.Maximum = 0;
            this.Quantitybar.Name = "Quantitybar";
            this.Quantitybar.Size = new System.Drawing.Size(104, 45);
            this.Quantitybar.TabIndex = 8;
            this.Quantitybar.Scroll += new System.EventHandler(this.Quantitybar_Scroll_1);
            // 
            // AddToCartBut
            // 
            this.AddToCartBut.Location = new System.Drawing.Point(113, 378);
            this.AddToCartBut.Name = "AddToCartBut";
            this.AddToCartBut.Size = new System.Drawing.Size(75, 23);
            this.AddToCartBut.TabIndex = 9;
            this.AddToCartBut.Text = "Add To Cart";
            this.AddToCartBut.UseVisualStyleBackColor = true;
            this.AddToCartBut.Click += new System.EventHandler(this.AddToCartBut_Click);
            // 
            // lblQuatity
            // 
            this.lblQuatity.AutoSize = true;
            this.lblQuatity.Location = new System.Drawing.Point(110, 315);
            this.lblQuatity.Name = "lblQuatity";
            this.lblQuatity.Size = new System.Drawing.Size(49, 13);
            this.lblQuatity.TabIndex = 10;
            this.lblQuatity.Text = "Quantity:";
            // 
            // cartUserControl11
            // 
            this.cartUserControl11.Location = new System.Drawing.Point(486, 12);
            this.cartUserControl11.Name = "cartUserControl11";
            this.cartUserControl11.Size = new System.Drawing.Size(443, 389);
            this.cartUserControl11.TabIndex = 7;
            // 
            // productUserControl1
            // 
            this.productUserControl1.Location = new System.Drawing.Point(93, 12);
            this.productUserControl1.Name = "productUserControl1";
            this.productUserControl1.Size = new System.Drawing.Size(387, 226);
            this.productUserControl1.TabIndex = 6;
          
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(960, 450);
            this.Controls.Add(this.lblQuatity);
            this.Controls.Add(this.AddToCartBut);
            this.Controls.Add(this.Quantitybar);
            this.Controls.Add(this.cartUserControl11);
            this.Controls.Add(this.productUserControl1);
            this.Controls.Add(this.button6);
            this.Controls.Add(this.button5);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Name = "Form1";
            this.Text = "Form1";
         
            ((System.ComponentModel.ISupportInitialize)(this.Quantitybar)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button6;
        private ProductUserControl productUserControl1;
        private lab_nr07_zd2.CartUserControl cartUserControl11;
        private System.Windows.Forms.TrackBar Quantitybar;
        private System.Windows.Forms.Button AddToCartBut;
        private System.Windows.Forms.Label lblQuatity;
    }
}

