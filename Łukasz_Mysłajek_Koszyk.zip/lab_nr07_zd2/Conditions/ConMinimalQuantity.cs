﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lab_nr07_zd2.Conditions
{
    public class ConMinimalQuantity : ICondition
    {
        public int MinQuantity { get; set; }

        public ConMinimalQuantity(int minQuantity)
        {
            MinQuantity = minQuantity;
        }

        public bool CheckCondition(int quantity)
        {
            if (quantity >= MinQuantity) return true;
            return false;
        }
    }
}
