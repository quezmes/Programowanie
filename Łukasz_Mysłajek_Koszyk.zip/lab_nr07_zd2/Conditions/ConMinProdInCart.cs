﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lab_nr07_zd2.Conditions
{
    class ConMinProdInCart : ICondition
    {
        private int MinCout { get; set; }

        public ConMinProdInCart(int minCout)
        {
            MinCout = minCout;
        }

        public bool CheckCondition(int quantity)
        {
            if (quantity >= MinCout) return true;
            return false;
        }
    }
}
