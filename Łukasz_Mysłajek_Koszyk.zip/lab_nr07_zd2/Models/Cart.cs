﻿using lab_nr06_zd2.Models;
using lab_nr07_zd2.Conditions;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lab_nr07_zd2.Models
{
    public class Cart
    {
        public Dictionary<Product, int> ProductsAndQuantity { get; set; } = new Dictionary<Product, int>(new ProductKeyComparer());
        public Discount Discount { get; set; } = new Discount("When buying products from a minimum of 2 categories, a 10% discount on the entire value of the order",
                                                                0.1m, new ConMinProdInCart(2));
        public void AddProductToCart(Product product, int quantity)
        {
            if (quantity > 0)
            {
                if (ProductsAndQuantity.ContainsKey(product))
                    ProductsAndQuantity[product] = quantity;
                else ProductsAndQuantity.Add(product, quantity);

            }
        }
        public void RemoveProductFromCart(String name)
        {
            ProductsAndQuantity.Remove(new Product() { Name = name });
        }

        public string[] GetPoductList()
        {

            return ProductsAndQuantity.Select(x => string.Join(" ", x.Key.Name,
                                                        "|", "Quantity:", x.Value,
                                                         "|", "Cost:", Math.Round(x.Key.Price * x.Value *
                                                         (x.Key.Discount != null ?
                                                         (x.Key.Discount.Condition.CheckCondition(x.Value) ? (1 - x.Key.Discount.Percent) : 1)
                                                         : 1),2)))
                                                         .ToArray();
        }


        public decimal GetTotalCost()
        {
            return ProductsAndQuantity.Sum(x => x.Key.Price * x.Value *
                                                                             (x.Key.Discount != null ?
                                                                             (x.Key.Discount.Condition.CheckCondition(x.Value) ? (1 - x.Key.Discount.Percent) : 1)
                                                                              : 1))
                                                                    * (Discount.Condition.CheckCondition(ProductsAndQuantity.Count()) ?
                                                                    (1-Discount.Percent)
                                                                    : 1);
        }

    }
}
