﻿using lab_nr06_zd2.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lab_nr07_zd2.Models
{
    class ProductKeyComparer : IEqualityComparer<Product>
    {
        public bool Equals(Product x, Product y)
        {
            return  x.Name == y.Name;
        }
        public int GetHashCode(Product product)
        {
            return product.Name.GetHashCode();
        }

        
    }
}
