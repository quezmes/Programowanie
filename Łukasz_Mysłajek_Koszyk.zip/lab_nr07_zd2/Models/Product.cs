﻿using lab_nr07_zd2.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lab_nr06_zd2.Models
{
    public class Product
    {
        public string Name { get; set; }
        public string ImageUrl { get; set; }
        public string Description { get; set; }
        public decimal Price { get; set; }
        public ProductCategory Category { get; set; }
        public string Source { get; set; }
        public  uint CurrentStock { get; set; }
        public Discount Discount { get; set; }

        public Product()
        {

        }
        public Product(string name, string imageUrl, string description, decimal price, ProductCategory category, string source, uint currentstock)
        {
            Name = name;
            ImageUrl = imageUrl;
            Description = description;
            Price = price;
            Category = category;
            Source = source;
            CurrentStock = currentstock;
        }
        public Product(string name, string imageUrl, string description, decimal price, ProductCategory category, string source, uint currentstock,Discount discount)
        {
            Name = name;
            ImageUrl = imageUrl;
            Description = description;
            Price = price;
            Category = category;
            Source = source;
            CurrentStock = currentstock;
            Discount = discount;
        }


    }
}
