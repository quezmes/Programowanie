﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lab_nr06_zd2.Models
{
    public enum ProductCategory
    {
        Beauty, Home, Fashion
    }
}
