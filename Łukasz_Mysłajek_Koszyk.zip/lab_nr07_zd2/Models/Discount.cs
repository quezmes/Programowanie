﻿
using lab_nr07_zd2.Conditions;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lab_nr07_zd2.Models
{
    public class Discount
    {
        public string Description { get; set; }
        public decimal Percent { get; set; }
        public ICondition Condition  { get; set; }

        public Discount(string desc, decimal percent, ICondition condition)
        {
            Description = desc;
            Percent = percent;
            Condition = condition;
        }
    }
}
