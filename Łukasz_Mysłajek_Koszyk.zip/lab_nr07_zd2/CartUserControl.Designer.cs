﻿namespace lab_nr07_zd2
{
    partial class CartUserControl
    {
        /// <summary> 
        /// Wymagana zmienna projektanta.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Wyczyść wszystkie używane zasoby.
        /// </summary>
        /// <param name="disposing">prawda, jeżeli zarządzane zasoby powinny zostać zlikwidowane; Fałsz w przeciwnym wypadku.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Kod wygenerowany przez Projektanta składników

        /// <summary> 
        /// Metoda wymagana do obsługi projektanta — nie należy modyfikować 
        /// jej zawartości w edytorze kodu.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.CartBox = new System.Windows.Forms.CheckedListBox();
            this.lblCart = new System.Windows.Forms.Label();
            this.RemoveBut = new System.Windows.Forms.Button();
            this.cartUserControlBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.lblTotalCost = new System.Windows.Forms.Label();
            this.lblDiscount = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.cartUserControlBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // CartBox
            // 
            this.CartBox.FormattingEnabled = true;
            this.CartBox.ImeMode = System.Windows.Forms.ImeMode.HangulFull;
            this.CartBox.Location = new System.Drawing.Point(19, 42);
            this.CartBox.Name = "CartBox";
            this.CartBox.Size = new System.Drawing.Size(364, 199);
            this.CartBox.TabIndex = 0;
            this.CartBox.SelectedIndexChanged += new System.EventHandler(this.Cart_SelectedIndexChanged);
            // 
            // lblCart
            // 
            this.lblCart.AutoSize = true;
            this.lblCart.Location = new System.Drawing.Point(16, 14);
            this.lblCart.Name = "lblCart";
            this.lblCart.Size = new System.Drawing.Size(29, 13);
            this.lblCart.TabIndex = 1;
            this.lblCart.Text = "Cart:";
            // 
            // RemoveBut
            // 
            this.RemoveBut.Location = new System.Drawing.Point(232, 262);
            this.RemoveBut.Name = "RemoveBut";
            this.RemoveBut.Size = new System.Drawing.Size(151, 31);
            this.RemoveBut.TabIndex = 12;
            this.RemoveBut.Text = "Remove Checked";
            this.RemoveBut.UseVisualStyleBackColor = true;
            this.RemoveBut.Click += new System.EventHandler(this.RemoveBut_Click);
            // 
            // lblTotalCost
            // 
            this.lblTotalCost.AutoSize = true;
            this.lblTotalCost.Location = new System.Drawing.Point(16, 244);
            this.lblTotalCost.Name = "lblTotalCost";
            this.lblTotalCost.Size = new System.Drawing.Size(35, 13);
            this.lblTotalCost.TabIndex = 13;
            this.lblTotalCost.Text = "label1";
            // 
            // lblDiscount
            // 
            this.lblDiscount.Location = new System.Drawing.Point(19, 302);
            this.lblDiscount.Name = "lblDiscount";
            this.lblDiscount.Size = new System.Drawing.Size(364, 98);
            this.lblDiscount.TabIndex = 14;
            this.lblDiscount.Text = "label1";
            // 
            // CartUserControl
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.lblDiscount);
            this.Controls.Add(this.lblTotalCost);
            this.Controls.Add(this.RemoveBut);
            this.Controls.Add(this.lblCart);
            this.Controls.Add(this.CartBox);
            this.Name = "CartUserControl";
            this.Size = new System.Drawing.Size(418, 418);
            ((System.ComponentModel.ISupportInitialize)(this.cartUserControlBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.CheckedListBox CartBox;
        private System.Windows.Forms.Label lblCart;
        private System.Windows.Forms.Button RemoveBut;
        private System.Windows.Forms.BindingSource cartUserControlBindingSource;
        private System.Windows.Forms.Label lblTotalCost;
        private System.Windows.Forms.Label lblDiscount;
    }
}
