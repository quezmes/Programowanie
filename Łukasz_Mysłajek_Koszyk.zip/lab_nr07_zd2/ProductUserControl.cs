﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using lab_nr06_zd2.Models;
using lab_nr07_zd2;
using lab_nr07_zd2.Models;

namespace lab_nr06_zd2
{
    public partial class ProductUserControl : UserControl
    {
        public ProductUserControl()
        {
            InitializeComponent();
        }


      

        public void Update(Product product)
        {
            lblName.Text = product.Name;
            lblDescription.Text = product.Description;
            lblCategory.Text = product.Category.ToString();
            lblPrice.Text = string.Format("{0:C2}", product.Price);
            pcbImage.Load(product.ImageUrl);

            

            if (product.Discount != null)
            {
                discountlbl.Visible = true;
                discountlbl.Text = product.Discount.Description;
            }else discountlbl.Visible = false;


        }

    }
}
