﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using lab_nr07_zd2.Models;
using lab_nr06_zd2.Models;

namespace lab_nr07_zd2
{
    public partial class CartUserControl : UserControl
    {
        private Cart _cart = new Cart();
        public CartUserControl()
        {
            InitializeComponent();
            lblDiscount.Text = _cart.Discount.Description;
        }

        
        public void UpdateCart( Product product,int quantity)
        {
            _cart.AddProductToCart(product, quantity);
            
            RefreshCart();
        }
        private void Cart_SelectedIndexChanged(object sender, EventArgs e)
        {
           
        }

        private void RefreshCart()
        {
           
           

            CartBox.Items.Clear();

            CartBox.Items.AddRange( _cart.GetPoductList());
            ShowTotalCost();

        }

        private void RemoveBut_Click(object sender, EventArgs e)
        {

           
           foreach (var item in CartBox.CheckedItems)
           {
                _cart.RemoveProductFromCart(item.ToString()
                                                 .Substring(0, item.ToString()
                                                 .IndexOf(" |")));
              
           }
            RefreshCart();
            
        }

        public void ShowTotalCost()
        {
            lblTotalCost.Text = String.Join(" ", "Total Cost", Math.Round(_cart.GetTotalCost(),2));
        }
   
      
    
    }
}
