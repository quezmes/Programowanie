﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ZombieApocalypseDemo
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            MessageBox.Show("Wszystkie metody w projekcie są autorskiego pochodzenia.Wszelkie kopie tego kodu , są wynikiem pomocy innym.");
            InitializeComponent();
            panHumanColor.BackColor = Settings.HumanColor;
            panZombieColor.BackColor = Settings.ZombieColor;
            panArmyColor.BackColor = Settings.ArmyColor;
        }
        private void butComitSet_Click(object sender, EventArgs e)
        {

            if (settingsUserControl1.GetUnits() != null)
            {
                simulation1.NrOfTours = 0;
                simulation1.Units = settingsUserControl1.GetUnits().ToList();
                simulation1.StartSimulation();
                
            }

        }


        private void butNextTour_Click(object sender, EventArgs e)
        {
         
            if (simulation1.Units != null)
            {
                simulation1.NextTour();
            }
                

        }
    }

}
