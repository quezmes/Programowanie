﻿namespace ZombieApocalypseDemo
{
    partial class Form1
    {
        /// <summary>
        /// Wymagana zmienna projektanta.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Wyczyść wszystkie używane zasoby.
        /// </summary>
        /// <param name="disposing">prawda, jeżeli zarządzane zasoby powinny zostać zlikwidowane; Fałsz w przeciwnym wypadku.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Kod generowany przez Projektanta formularzy systemu Windows

        /// <summary>
        /// Metoda wymagana do obsługi projektanta — nie należy modyfikować
        /// jej zawartości w edytorze kodu.
        /// </summary>
        private void InitializeComponent()
        {
            this.butComitSet = new System.Windows.Forms.Button();
            this.butNextTour = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.panHumanColor = new System.Windows.Forms.Panel();
            this.panZombieColor = new System.Windows.Forms.Panel();
            this.panArmyColor = new System.Windows.Forms.Panel();
            this.simulation1 = new ZombieApocalypseDemo.Simulation();
            this.settingsUserControl1 = new ZombieApocalypseDemo.SettingsUserControl();
            this.SuspendLayout();
            // 
            // butComitSet
            // 
            this.butComitSet.Location = new System.Drawing.Point(353, 138);
            this.butComitSet.Name = "butComitSet";
            this.butComitSet.Size = new System.Drawing.Size(90, 43);
            this.butComitSet.TabIndex = 1;
            this.butComitSet.Text = "Commit Settings";
            this.butComitSet.UseVisualStyleBackColor = true;
            this.butComitSet.Click += new System.EventHandler(this.butComitSet_Click);
            // 
            // butNextTour
            // 
            this.butNextTour.Location = new System.Drawing.Point(353, 188);
            this.butNextTour.Name = "butNextTour";
            this.butNextTour.Size = new System.Drawing.Size(75, 23);
            this.butNextTour.TabIndex = 3;
            this.butNextTour.Text = "NextTour";
            this.butNextTour.UseVisualStyleBackColor = true;
            this.butNextTour.Click += new System.EventHandler(this.butNextTour_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(290, 20);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(70, 13);
            this.label1.TabIndex = 6;
            this.label1.Text = "Human color:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(290, 45);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(71, 13);
            this.label2.TabIndex = 7;
            this.label2.Text = "Zombie color:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(290, 68);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(59, 13);
            this.label3.TabIndex = 8;
            this.label3.Text = "Army color:";
            // 
            // panHumanColor
            // 
            this.panHumanColor.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.panHumanColor.Location = new System.Drawing.Point(389, 20);
            this.panHumanColor.Name = "panHumanColor";
            this.panHumanColor.Size = new System.Drawing.Size(16, 12);
            this.panHumanColor.TabIndex = 9;
            // 
            // panZombieColor
            // 
            this.panZombieColor.Location = new System.Drawing.Point(389, 46);
            this.panZombieColor.Name = "panZombieColor";
            this.panZombieColor.Size = new System.Drawing.Size(16, 12);
            this.panZombieColor.TabIndex = 10;
            // 
            // panArmyColor
            // 
            this.panArmyColor.Location = new System.Drawing.Point(389, 69);
            this.panArmyColor.Name = "panArmyColor";
            this.panArmyColor.Size = new System.Drawing.Size(16, 12);
            this.panArmyColor.TabIndex = 10;
            // 
            // simulation1
            // 
            this.simulation1.Location = new System.Drawing.Point(488, 13);
            this.simulation1.Name = "simulation1";
            this.simulation1.NrOfTours = 0;
            this.simulation1.Size = new System.Drawing.Size(373, 399);
            this.simulation1.TabIndex = 5;
            // 
            // settingsUserControl1
            // 
            this.settingsUserControl1.Location = new System.Drawing.Point(9, 13);
            this.settingsUserControl1.Name = "settingsUserControl1";
            this.settingsUserControl1.Size = new System.Drawing.Size(300, 500);
            this.settingsUserControl1.TabIndex = 4;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(873, 439);
            this.Controls.Add(this.panArmyColor);
            this.Controls.Add(this.panZombieColor);
            this.Controls.Add(this.panHumanColor);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.simulation1);
            this.Controls.Add(this.butNextTour);
            this.Controls.Add(this.butComitSet);
            this.Controls.Add(this.settingsUserControl1);
            this.Name = "Form1";
            this.Text = "Zombie Apocalypse";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button butComitSet;
        private System.Windows.Forms.Button butNextTour;
      
        private ZombieApocalypseDemo.SettingsUserControl settingsUserControl1;
        private Simulation simulation1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Panel panHumanColor;
        private System.Windows.Forms.Panel panZombieColor;
        private System.Windows.Forms.Panel panArmyColor;
    }
}

