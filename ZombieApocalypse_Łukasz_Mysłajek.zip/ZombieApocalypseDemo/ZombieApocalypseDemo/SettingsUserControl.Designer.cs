﻿namespace ZombieApocalypseDemo
{
    partial class SettingsUserControl
    {
        /// <summary> 
        /// Wymagana zmienna projektanta.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Wyczyść wszystkie używane zasoby.
        /// </summary>
        /// <param name="disposing">prawda, jeżeli zarządzane zasoby powinny zostać zlikwidowane; Fałsz w przeciwnym wypadku.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Kod wygenerowany przez Projektanta składników

        /// <summary> 
        /// Metoda wymagana do obsługi projektanta — nie należy modyfikować 
        /// jej zawartości w edytorze kodu.
        /// </summary>
        private void InitializeComponent()
        {
            this.tbArmies = new System.Windows.Forms.TextBox();
            this.lblArmies = new System.Windows.Forms.Label();
            this.tbZombies = new System.Windows.Forms.TextBox();
            this.lblZombies = new System.Windows.Forms.Label();
            this.tbHumans = new System.Windows.Forms.TextBox();
            this.lblHumans = new System.Windows.Forms.Label();
            this.lblNrOfTours = new System.Windows.Forms.Label();
            this.tbNrOfTours = new System.Windows.Forms.TextBox();
            this.tbMinMoney = new System.Windows.Forms.TextBox();
            this.lblMinMoney = new System.Windows.Forms.Label();
            this.tbMaxMoney = new System.Windows.Forms.TextBox();
            this.lblMaxMoney = new System.Windows.Forms.Label();
            this.tbMandat = new System.Windows.Forms.TextBox();
            this.lblMandat = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.tbStamina = new System.Windows.Forms.TextBox();
            this.lblArmyStamina = new System.Windows.Forms.Label();
            this.tbStrength = new System.Windows.Forms.TextBox();
            this.lblStrength = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // tbArmies
            // 
            this.tbArmies.Location = new System.Drawing.Point(105, 222);
            this.tbArmies.Name = "tbArmies";
            this.tbArmies.Size = new System.Drawing.Size(68, 20);
            this.tbArmies.TabIndex = 11;
            this.tbArmies.Text = "12";
            // 
            // lblArmies
            // 
            this.lblArmies.AutoSize = true;
            this.lblArmies.Location = new System.Drawing.Point(0, 225);
            this.lblArmies.Name = "lblArmies";
            this.lblArmies.Size = new System.Drawing.Size(93, 13);
            this.lblArmies.TabIndex = 10;
            this.lblArmies.Text = "Number of Armies:";
            // 
            // tbZombies
            // 
            this.tbZombies.Location = new System.Drawing.Point(105, 113);
            this.tbZombies.Name = "tbZombies";
            this.tbZombies.Size = new System.Drawing.Size(68, 20);
            this.tbZombies.TabIndex = 9;
            this.tbZombies.Text = "7";
            // 
            // lblZombies
            // 
            this.lblZombies.AutoSize = true;
            this.lblZombies.Location = new System.Drawing.Point(0, 116);
            this.lblZombies.Name = "lblZombies";
            this.lblZombies.Size = new System.Drawing.Size(102, 13);
            this.lblZombies.TabIndex = 8;
            this.lblZombies.Text = "Number of Zombies:";
            // 
            // tbHumans
            // 
            this.tbHumans.Location = new System.Drawing.Point(105, 23);
            this.tbHumans.Name = "tbHumans";
            this.tbHumans.Size = new System.Drawing.Size(68, 20);
            this.tbHumans.TabIndex = 7;
            this.tbHumans.TabStop = false;
            this.tbHumans.Text = "20";
            // 
            // lblHumans
            // 
            this.lblHumans.AutoSize = true;
            this.lblHumans.Location = new System.Drawing.Point(0, 26);
            this.lblHumans.Name = "lblHumans";
            this.lblHumans.Size = new System.Drawing.Size(99, 13);
            this.lblHumans.TabIndex = 6;
            this.lblHumans.Text = "Number of humans:";
            // 
            // lblNrOfTours
            // 
            this.lblNrOfTours.AutoSize = true;
            this.lblNrOfTours.Location = new System.Drawing.Point(0, 142);
            this.lblNrOfTours.Name = "lblNrOfTours";
            this.lblNrOfTours.Size = new System.Drawing.Size(121, 13);
            this.lblNrOfTours.TabIndex = 12;
            this.lblNrOfTours.Text = "Number of zombie tours:";
            // 
            // tbNrOfTours
            // 
            this.tbNrOfTours.Location = new System.Drawing.Point(127, 139);
            this.tbNrOfTours.Name = "tbNrOfTours";
            this.tbNrOfTours.Size = new System.Drawing.Size(68, 20);
            this.tbNrOfTours.TabIndex = 13;
            this.tbNrOfTours.Text = "3";
            // 
            // tbMinMoney
            // 
            this.tbMinMoney.Location = new System.Drawing.Point(127, 329);
            this.tbMinMoney.Name = "tbMinMoney";
            this.tbMinMoney.Size = new System.Drawing.Size(68, 20);
            this.tbMinMoney.TabIndex = 15;
            this.tbMinMoney.Text = "500";
            // 
            // lblMinMoney
            // 
            this.lblMinMoney.AutoSize = true;
            this.lblMinMoney.Location = new System.Drawing.Point(0, 332);
            this.lblMinMoney.Name = "lblMinMoney";
            this.lblMinMoney.Size = new System.Drawing.Size(111, 13);
            this.lblMinMoney.TabIndex = 14;
            this.lblMinMoney.Text = "Min amount of money:";
            // 
            // tbMaxMoney
            // 
            this.tbMaxMoney.Location = new System.Drawing.Point(127, 355);
            this.tbMaxMoney.Name = "tbMaxMoney";
            this.tbMaxMoney.Size = new System.Drawing.Size(68, 20);
            this.tbMaxMoney.TabIndex = 17;
            this.tbMaxMoney.Text = "1500";
            // 
            // lblMaxMoney
            // 
            this.lblMaxMoney.AutoSize = true;
            this.lblMaxMoney.Location = new System.Drawing.Point(0, 358);
            this.lblMaxMoney.Name = "lblMaxMoney";
            this.lblMaxMoney.Size = new System.Drawing.Size(114, 13);
            this.lblMaxMoney.TabIndex = 16;
            this.lblMaxMoney.Text = "Max amount of money:";
            // 
            // tbMandat
            // 
            this.tbMandat.Location = new System.Drawing.Point(127, 381);
            this.tbMandat.Name = "tbMandat";
            this.tbMandat.Size = new System.Drawing.Size(68, 20);
            this.tbMandat.TabIndex = 19;
            this.tbMandat.Text = "751";
            // 
            // lblMandat
            // 
            this.lblMandat.AutoSize = true;
            this.lblMandat.Location = new System.Drawing.Point(0, 384);
            this.lblMandat.Name = "lblMandat";
            this.lblMandat.Size = new System.Drawing.Size(96, 13);
            this.lblMandat.TabIndex = 18;
            this.lblMandat.Text = "Amount of mandat:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label1.Location = new System.Drawing.Point(2, 90);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(140, 20);
            this.label1.TabIndex = 20;
            this.label1.Text = "Zombie Settings";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label2.Location = new System.Drawing.Point(2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(138, 20);
            this.label2.TabIndex = 21;
            this.label2.Text = "Human Settings";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label3.Location = new System.Drawing.Point(3, 199);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(121, 20);
            this.label3.TabIndex = 22;
            this.label3.Text = "Army Settings";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label4.Location = new System.Drawing.Point(2, 306);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(133, 20);
            this.label4.TabIndex = 23;
            this.label4.Text = "Global Settings";
            // 
            // tbStamina
            // 
            this.tbStamina.Location = new System.Drawing.Point(105, 248);
            this.tbStamina.Name = "tbStamina";
            this.tbStamina.Size = new System.Drawing.Size(68, 20);
            this.tbStamina.TabIndex = 25;
            this.tbStamina.Text = "5";
            // 
            // lblArmyStamina
            // 
            this.lblArmyStamina.AutoSize = true;
            this.lblArmyStamina.Location = new System.Drawing.Point(0, 251);
            this.lblArmyStamina.Name = "lblArmyStamina";
            this.lblArmyStamina.Size = new System.Drawing.Size(97, 13);
            this.lblArmyStamina.TabIndex = 24;
            this.lblArmyStamina.Text = "Amount of stamina:";
            // 
            // tbStrength
            // 
            this.tbStrength.Location = new System.Drawing.Point(105, 165);
            this.tbStrength.Name = "tbStrength";
            this.tbStrength.Size = new System.Drawing.Size(68, 20);
            this.tbStrength.TabIndex = 27;
            this.tbStrength.Text = "3";
            // 
            // lblStrength
            // 
            this.lblStrength.AutoSize = true;
            this.lblStrength.Location = new System.Drawing.Point(0, 168);
            this.lblStrength.Name = "lblStrength";
            this.lblStrength.Size = new System.Drawing.Size(99, 13);
            this.lblStrength.TabIndex = 26;
            this.lblStrength.Text = "Amount of strength:";
            // 
            // SettingsUserControl
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.tbStrength);
            this.Controls.Add(this.lblStrength);
            this.Controls.Add(this.tbStamina);
            this.Controls.Add(this.lblArmyStamina);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.tbMandat);
            this.Controls.Add(this.lblMandat);
            this.Controls.Add(this.tbMaxMoney);
            this.Controls.Add(this.lblMaxMoney);
            this.Controls.Add(this.tbMinMoney);
            this.Controls.Add(this.lblMinMoney);
            this.Controls.Add(this.tbNrOfTours);
            this.Controls.Add(this.lblNrOfTours);
            this.Controls.Add(this.tbArmies);
            this.Controls.Add(this.lblArmies);
            this.Controls.Add(this.tbZombies);
            this.Controls.Add(this.lblZombies);
            this.Controls.Add(this.tbHumans);
            this.Controls.Add(this.lblHumans);
            this.Name = "SettingsUserControl";
            this.Size = new System.Drawing.Size(376, 437);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox tbArmies;
        private System.Windows.Forms.Label lblArmies;
        private System.Windows.Forms.TextBox tbZombies;
        private System.Windows.Forms.Label lblZombies;
        private System.Windows.Forms.TextBox tbHumans;
        private System.Windows.Forms.Label lblHumans;
        private System.Windows.Forms.Label lblNrOfTours;
        private System.Windows.Forms.TextBox tbNrOfTours;
        private System.Windows.Forms.TextBox tbMinMoney;
        private System.Windows.Forms.Label lblMinMoney;
        private System.Windows.Forms.TextBox tbMaxMoney;
        private System.Windows.Forms.Label lblMaxMoney;
        private System.Windows.Forms.TextBox tbMandat;
        private System.Windows.Forms.Label lblMandat;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox tbStamina;
        private System.Windows.Forms.Label lblArmyStamina;
        private System.Windows.Forms.TextBox tbStrength;
        private System.Windows.Forms.Label lblStrength;
    }
}
