﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ZombieApocalypseDemo.Units
{

    public class Army : Human
    {
        public Army(Label label, decimal money, int stamina) : base(label, money)
        {
            Stamina = stamina;
        }

        public int Stamina { get; set; }

        public override string ToString()
        {
            return String.Join("\n", base.ToString(), $"Stamina: {Stamina}");
        }


    }
}
