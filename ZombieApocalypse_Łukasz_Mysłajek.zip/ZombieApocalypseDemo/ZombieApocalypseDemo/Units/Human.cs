﻿using System;
using System.ComponentModel;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ZombieApocalypseDemo.Units
{
  
    public class Human
    {



        public decimal Money { get; set; }

        public Label Label { get; set; } = new Label();

        public Human(Label label, decimal money)
        {

            Label = label;



            Money = money;

        }


        public override string ToString()
        {
            return String.Join("\n", $"X: {Label.Location.X}", $"Y: {Label.Location.Y}", $"Money: {Money}");
        }


    }
}
