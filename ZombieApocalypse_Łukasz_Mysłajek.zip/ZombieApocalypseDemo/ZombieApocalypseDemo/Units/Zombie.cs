﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ZombieApocalypseDemo.Units
{
 
    public class Zombie : Human
    {
        public Zombie(Label label, decimal money, int nrOfTours, int strength) : base(label, money)
        {
            NrOfTours = nrOfTours;
            Strength = strength;
        }

        public int NrOfTours { get; set; }
        public int Strength { get; set; }

        public override string ToString()
        {
            return string.Join("\n", base.ToString(), $"Nr of Tours: {NrOfTours}", $"Strentgh: {Strength}");
        }



    }
}
