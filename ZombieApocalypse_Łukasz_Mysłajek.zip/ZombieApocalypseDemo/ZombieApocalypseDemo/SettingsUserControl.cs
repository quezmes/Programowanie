﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ZombieApocalypseDemo.Units;
using System.Collections.ObjectModel;

namespace ZombieApocalypseDemo
{
    public partial class SettingsUserControl : UserControl
    {
        private static Random rnd = new Random();
        public SettingsUserControl()
        {
            InitializeComponent();
        }

        private bool IsTextBoxesNotEmpty()
        {
            foreach (var textBox in Controls.OfType<TextBox>())
                if (string.IsNullOrEmpty(textBox.Text.Trim()))
                    return false;

            return true;
        }
        private bool SetSettings()
        {
            if (!IsTextBoxesNotEmpty()) MessageBox.Show("Text box can't be empty");
            else
            {
                Settings.NrOfHumans = int.Parse(tbHumans.Text);

                Settings.NrOFZombie = int.Parse(tbZombies.Text);
                Settings.ZombieStrength = int.Parse(tbStrength.Text);
                Settings.ZombieTour = int.Parse(tbNrOfTours.Text);

                Settings.NrOfArmy = int.Parse(tbArmies.Text);
                Settings.ArmyStamina = int.Parse(tbStamina.Text);


                Settings.MinMoney = int.Parse(tbMinMoney.Text);
                Settings.MaxMoney = int.Parse(tbMaxMoney.Text);
                Settings.Mandat = decimal.Parse(tbMandat.Text);

                return true;

            }
            return false;
        }
        public IEnumerable<Human> GetUnits()
        {
            if (SetSettings())
            {
                ICollection<Human> Units = new Collection<Human>();
                HashSet<Point> coord = new HashSet<Point>();
                int range = 250 / 8;

                int nrOfTours = int.Parse(tbNrOfTours.Text);


                int tagger = 0;

                for (int i = 0; i < int.Parse(tbHumans.Text); i++)
                {
                    while (!coord.Add(new Point(rnd.Next(range), rnd.Next(range)))) ;
                    Units.Add(new Human(new Label()
                    {
                        Name = tagger.ToString(),
                        Location = coord.Last(),
                        BackColor = Settings.HumanColor,
                        Tag = tagger,
                        Size = new Size(7, 7)
                    },
                                     rnd.Next(Settings.MinMoney, Settings.MaxMoney)));
                    tagger++;
                }

                for (int i = 0; i < int.Parse(tbZombies.Text); i++)
                {
                    while (!coord.Add(new Point(rnd.Next(range), rnd.Next(range)))) ;
                    Units.Add(new Zombie(new Label()
                    {
                        Name = tagger.ToString(),
                        Location = coord.Last(),
                        BackColor = Settings.ZombieColor,
                        Tag = tagger,
                        Size = new Size(7, 7)
                    },
                                       rnd.Next(Settings.MinMoney, Settings.MaxMoney),
                                       nrOfTours, rnd.Next(1, Settings.ZombieStrength)));
                    tagger++;
                }
                for (int i = 0; i < int.Parse(tbArmies.Text); i++)
                {
                    while (!coord.Add(new Point(rnd.Next(range), rnd.Next(range)))) ;
                    Units.Add(new Army(new Label()
                    {
                        Name = tagger.ToString(),
                        Location = coord.Last(),
                        BackColor = Settings.ArmyColor,
                        Tag = tagger,
                        Size = new Size(7, 7)
                    },
                                       rnd.Next(Settings.MinMoney, Settings.MaxMoney),
                                       rnd.Next(1, Settings.ArmyStamina)));
                    tagger++;
                }

                foreach (var unit in Units)
                {
                    unit.Label.Location = new Point(unit.Label.Location.X * 8, unit.Label.Location.Y * 8);

                }

                return Units;
            }

            return null;
        }


    }
}
