﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ZombieApocalypseDemo.Units;
using System.Runtime.CompilerServices;
using System.Threading;
using System.Linq.Expressions;
using System.CodeDom;

namespace ZombieApocalypseDemo
{

    public partial class Simulation : UserControl
    {
        [Browsable(false)]
        [EditorBrowsable(EditorBrowsableState.Never)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        private static Dictionary<(Type, Type), Expression<Func<Human, Human, bool>>> Conditions { get; set; } = new Dictionary<(Type, Type), Expression<Func<Human, Human, bool>>>();
        private static Random rnd = new Random();
        [Browsable(false)]
        [EditorBrowsable(EditorBrowsableState.Never)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public List<Human> Units { get; set; } = new List<Human>();
        public int NrOfTours { get; set; } = 0;

        private List<object> AlreadyMet { get; set; } = new List<object>();

        public Simulation()
        {
            AddConditions();
            InitializeComponent();
        }

        private void AddConditions()
        {
            Conditions.Add((typeof(Zombie), typeof(Human)), (x, y) => Zombification(x, y));
            Conditions.Add((typeof(Human), typeof(Zombie)), (x, y) => Zombification(y, x));

            Conditions.Add((typeof(Army), typeof(Human)), (x, y) => MilitaryControl(x, y));
            Conditions.Add((typeof(Human), typeof(Army)), (x, y) => MilitaryControl(y, x));

            Conditions.Add((typeof(Army), typeof(Zombie)), (x, y) => Battle(x, y));
            Conditions.Add((typeof(Zombie), typeof(Army)), (x, y) => Battle(y, x));
        }


        public void StartSimulation()
        {
            ClearMap();
            foreach (var unit in Units)
            {
                unit.Label.Parent = this;
                toolTip1.SetToolTip(unit.Label, unit.ToString());
            }

            panelMap.SendToBack();
            UpdateInfo();
        }


        public void NextTour()
        {
            int maxMove = 20;
            int x, y;
            foreach (var label in Units.Select((input, index) => new { input, index })
                                          .Where(z => !(Units[z.index].Money <= 0 && Units[z.index] is Human h)).ToArray()
                                          .Select(z => z.input.Label))
            {
                x = rnd.Next(-maxMove, maxMove);
                y = rnd.Next(-maxMove, maxMove);

                for (int i = 1, j = 1; i <= Math.Abs(x) && j <= Math.Abs(y); i++, j++)
                {

                    CheckColision(label);
                    if ((label.Bounds.Right >= panelMap.Bounds.Right) || (label.Bounds.Left <= panelMap.Bounds.Left)) x = -x;
                    if ((label.Bounds.Top >= panelMap.Bounds.Top) || (label.Bounds.Bottom <= panelMap.Bounds.Bottom)) y = -y;


                    if (i <= Math.Abs(x))
                        label.Location = new Point(label.Location.X + (x > 0 ? 1 : -1), label.Location.Y);
                    if (j <= Math.Abs(y))
                        if (label.Location.Y != panelMap.Height - label.Size.Height)
                            label.Location = new Point(label.Location.X, label.Location.Y + (y > 0 ? 1 : -1));


                }
                AlreadyMet.Clear();

            }
            CheckZombieTours();
            UpdateInfo();
        }
        private void CheckColision(Label label)
        {
            AlreadyMet.Add(label.Tag);
            foreach (var item in Units.Where(x => !AlreadyMet.Contains(x.Label.Tag)).ToArray().Select(x => x.Label))
            {
                if (label.Bounds.IntersectsWith(item.Bounds))
                {
                    CheckType(Units[(int)label.Tag], Units[(int)item.Tag]);

                    AlreadyMet.Add(item.Tag);
                }
            }

        }

        private void CheckType(Human attacker, Human defender)
        {


            if (!attacker.GetType().Equals(defender.GetType()))
            {
                if (Conditions.TryGetValue((attacker.GetType(), defender.GetType()), out var value))
                    value.Compile().Invoke(attacker, defender);

            }

        }

        private bool MilitaryControl(Human army, Human human)
        {
            if (human.Money < Settings.Mandat)
            {
                Units[(int)human.Label.Tag] = new Army(human.Label, human.Money, rnd.Next(1, Settings.ArmyStamina));
            }
            else Units[(int)human.Label.Tag].Money -= Settings.Mandat;
            return true;
        }
        private bool Battle(Human army, Human zombie)
        {
            if ((army as Army).Stamina > (zombie as Zombie).Strength)
            {
                Units[(int)zombie.Label.Tag] = new Human(zombie.Label, zombie.Money);
                Units[(int)zombie.Label.Tag].Label.BackColor = Settings.HumanColor;
                (Units[(int)army.Label.Tag] as Army).Stamina -= (zombie as Zombie).Strength;
            }
            else
            {
                Zombification(zombie, army);
            }
            return true;
        }
        private bool Zombification(Human opponent, Human toZombie)
        {

            int tag = (int)toZombie.Label.Tag;
            Units[tag] = new Zombie(Units[tag].Label, Units[tag].Money, Settings.ZombieTour, Settings.ZombieStrength);
            Units[tag].Label.BackColor = Settings.ZombieColor;
            return true;

        }
        private void UnZombification(int tag)
        {
            Units[tag] = new Human(Units[tag].Label, Units[tag].Money);
            Units[tag].Label.BackColor = Settings.HumanColor;

        }

        private void CheckZombieTours()
        {
            foreach (var zombie in Units.OfType<Zombie>().ToArray())
            {
                zombie.NrOfTours--;
                if (zombie.NrOfTours == 0) UnZombification((int)zombie.Label.Tag);
            }
        }
        private void ClearMap()
        {
            foreach (var lejbel in Units.Select(x => x.Label))
            {
                this.Controls.RemoveByKey(lejbel.Name);
            }
        }

        private void UpdateInfo()
        {

            lblTours.Text = String.Join(" ", "Nr of tours: ", ++NrOfTours);
            lblArmy.Text = String.Join(" ", "Nr of Army: ", Units.OfType<Army>().Count().ToString());
            lblHuman.Text = String.Join(" ", "Nr of Human: ", Units.Where(x => x.Label.BackColor.Equals(Color.Yellow)).Count().ToString());
            lblZombie.Text = String.Join(" ", "Nr of Zombie: ", Units.OfType<Zombie>().Count().ToString());
        }




    }
}
