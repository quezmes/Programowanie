﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ZombieApocalypseDemo
{
    public static class Settings
    {
        public static int NrOfHumans { get; set; }

        public static int NrOFZombie { get; set; }
        public static int ZombieTour { get; set; }
        public static int ZombieStrength { get; set; }

        public static int NrOfArmy { get; set; }
        public static int ArmyStamina { get; set; }

        public static int MinMoney { get; set; }
        public static int MaxMoney { get; set; }
        public static decimal Mandat { get; set; }

        public static Color HumanColor { get; set; } = Color.Yellow;
        public static Color ZombieColor { get; set; } = Color.Red;
        public static Color ArmyColor { get; set; } = Color.Green;
    }
}
