﻿namespace ZombieApocalypseDemo
{
    partial class Simulation
    {
        /// <summary> 
        /// Wymagana zmienna projektanta.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Wyczyść wszystkie używane zasoby.
        /// </summary>
        /// <param name="disposing">prawda, jeżeli zarządzane zasoby powinny zostać zlikwidowane; Fałsz w przeciwnym wypadku.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Kod wygenerowany przez Projektanta składników

        /// <summary> 
        /// Metoda wymagana do obsługi projektanta — nie należy modyfikować 
        /// jej zawartości w edytorze kodu.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.panelMap = new System.Windows.Forms.Panel();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.lblTours = new System.Windows.Forms.Label();
            this.lblZombie = new System.Windows.Forms.Label();
            this.lblHuman = new System.Windows.Forms.Label();
            this.lblArmy = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // panelMap
            // 
            this.panelMap.BackColor = System.Drawing.Color.Black;
            this.panelMap.Location = new System.Drawing.Point(0, 0);
            this.panelMap.Name = "panelMap";
            this.panelMap.Size = new System.Drawing.Size(256, 256);
            this.panelMap.TabIndex = 1;
            // 
            // lblTours
            // 
            this.lblTours.AutoSize = true;
            this.lblTours.Location = new System.Drawing.Point(13, 272);
            this.lblTours.Name = "lblTours";
            this.lblTours.Size = new System.Drawing.Size(0, 13);
            this.lblTours.TabIndex = 2;
            // 
            // lblZombie
            // 
            this.lblZombie.AutoSize = true;
            this.lblZombie.Location = new System.Drawing.Point(13, 285);
            this.lblZombie.Name = "lblZombie";
            this.lblZombie.Size = new System.Drawing.Size(0, 13);
            this.lblZombie.TabIndex = 4;
            // 
            // lblHuman
            // 
            this.lblHuman.AutoSize = true;
            this.lblHuman.Location = new System.Drawing.Point(13, 298);
            this.lblHuman.Name = "lblHuman";
            this.lblHuman.Size = new System.Drawing.Size(0, 13);
            this.lblHuman.TabIndex = 6;
            // 
            // lblArmy
            // 
            this.lblArmy.AutoSize = true;
            this.lblArmy.Location = new System.Drawing.Point(13, 311);
            this.lblArmy.Name = "lblArmy";
            this.lblArmy.Size = new System.Drawing.Size(0, 13);
            this.lblArmy.TabIndex = 8;
            // 
            // Simulation
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.lblArmy);
            this.Controls.Add(this.lblHuman);
            this.Controls.Add(this.lblZombie);
            this.Controls.Add(this.lblTours);
            this.Controls.Add(this.panelMap);
            this.Name = "Simulation";
            this.Size = new System.Drawing.Size(373, 399);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Panel panelMap;
        private System.Windows.Forms.ToolTip toolTip1;
        private System.Windows.Forms.Label lblTours;
        private System.Windows.Forms.Label lblZombie;
        private System.Windows.Forms.Label lblHuman;
        private System.Windows.Forms.Label lblArmy;
    }
}

